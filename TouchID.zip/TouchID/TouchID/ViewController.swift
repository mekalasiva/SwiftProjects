//
//  ViewController.swift
//  TouchID
//
//  Created by Siva Meka on 9/5/17.
//  Copyright © 2017 Siva. All rights reserved.
//

import UIKit
import LocalAuthentication


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        let authContext:LAContext = LAContext()
//        var error:NSError?
//        
//        //Is Touch ID hardware available & configured?
//        if(authContext.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error:&error))
//        {
//            //Perform Touch ID auth
//            authContext.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Testing Touch ID", reply: {(wasSuccessful:Bool, error:NSError?) in
//                
//                if(wasSuccessful)
//                {
//                    //User authenticated
//                    self.writeOutAuthResult(authError: error)
//                }
//                else
//                {
//                    //There are a few reasons why it can fail, we'll write them out to the user in the label
//                    self.writeOutAuthResult(authError: error)
//                }
//                
//            } as! (Bool, Error?) -> Void)
//            
//        }
//        else
//        {
//            //Missing the hardware or Touch ID isn't configured
//            self.writeOutAuthResult(authError: error)
//        }
        
       let authenticationContext = LAContext()
        var error:NSError?
        
        guard authenticationContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)else{
            showAlertViewIfNoBiometric()
            return
        }
        
        authenticationContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Authentication issue", reply: {[unowned self] (success, error) -> Void in
            if(success){
                self.navigateToAuthenticatedViewController()
            }else{
                
                if let error=error{
                    
                    let message=self.errorMessage(error as! Int)
                    
                    self.showAlertViewAfterEvaluatingPolicyWithMessage(message: message)
                }
            }
        
        })
    }
    
    func showAlertViewIfNoBiometric(){
        showAlertWithTitle(title: "error", message: "This device does not have a TouchID sensor.")
    }

    func showAlertViewAfterEvaluatingPolicyWithMessage(message:String){
        showAlertWithTitle(title: "Error", message: message)
    }
    
    
    func showAlertWithTitle(title:String,message:String){
        
        let alertVC=UIAlertController(title:title ,message:message, preferredStyle:.alert)
        
        let okAction=UIAlertAction(title: "Ok", style: .default, handler: nil)
        alertVC.addAction(okAction)
        DispatchQueue.main.async(){
            self.present(alertVC, animated: true,completion: nil)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func writeOutAuthResult(authError:NSError?)
    {
        DispatchQueue.main.async(execute: {() in
            if authError != nil
            {
                //self.lblAuthResult.textColor = UIColor.redColor()
                //self.lblAuthResult.text = possibleError.localizedDescription
            }
            else
            {
                //self.lblAuthResult.textColor = UIColor.greenColor()
                //self.lblAuthResult.text = "Authentication successful."
            }
        })
        
    }
    func navigateToAuthenticatedViewController(){
        
        if let loggedInVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") {
              
            DispatchQueue.main.async() { () -> Void in
                
                self.navigationController?.pushViewController(loggedInVC, animated: true)
                
            }
            
        }
       
    }
    
    func errorMessage( _ errorCode:Int)->String{
        var message=""
        
        switch errorCode {
        case LAError.appCancel.rawValue:
            message = "Authentication was cancelled by application"
            
        case LAError.authenticationFailed.rawValue:
            message = "The user failed to provide valid credentials"
            
        case LAError.invalidContext.rawValue:
            message = "The context is invalid"
            
        case LAError.passcodeNotSet.rawValue:
            message = "Passcode is not set on the device"
            
        case LAError.systemCancel.rawValue:
            message = "Authentication was cancelled by the system"
            
        case LAError.touchIDLockout.rawValue:
            message = "Too many failed attempts."
            
        case LAError.touchIDNotAvailable.rawValue:
            message = "TouchID is not available on the device"
            
        case LAError.userCancel.rawValue:
            message = "The user did cancel"
            
        case LAError.userFallback.rawValue:
            message = "The user chose to use the fallback"

        default:
            message="The user did cancel"
        }
        return message
    }
    
    
    


}

